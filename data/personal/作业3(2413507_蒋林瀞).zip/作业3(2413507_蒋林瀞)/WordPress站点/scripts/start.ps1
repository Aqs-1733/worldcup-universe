﻿# 文件作用：一键启动作业3的 WordPress 站点。首次运行时自动初始化本地数据库并导入 database\hw3_wordpress.sql，之后直接启动。
# 需要电脑上有 PHP 7.4 及以上和 MySQL 8 / MariaDB 10.4 及以上（例如 XAMPP）；不在 PATH 中时可用 -Php、-MySqld 指定。
# 作者：蒋林瀞_2413507
param(
 [string]$Php = '',
 [string]$MySqld = '',
 [int]$HttpPort = 8085,
 [int]$DbPort = 3338,
 [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Data = Join-Path $Root 'data'
$Logs = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $Data, $Logs | Out-Null
# MySQL / MariaDB 不能在含中文的路径下运行，所以数据库文件放在一个纯英文路径里
$DbHome = Join-Path $env:LOCALAPPDATA 'GeminaiLong-hw3'
if ($DbHome -match '[^\x20-\x7E]') { $DbHome = 'C:\GeminaiLong-hw3' }
New-Item -ItemType Directory -Force -Path $DbHome | Out-Null

function Find-Program([string]$given, [string]$name, [string[]]$candidates) {
  if ($given) { if (Test-Path -LiteralPath $given) { return (Resolve-Path -LiteralPath $given).Path }; throw "找不到 $given" }
  $cmd = Get-Command $name -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($cmd) { return $cmd.Source }
  foreach ($c in $candidates) { $hit = Get-Item -Path $c -ErrorAction SilentlyContinue | Select-Object -Last 1; if ($hit) { return $hit.FullName } }
  return $null
}
function Test-Port([int]$port) { [bool](Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue) }

# 1. 找到 PHP 和 MySQL / MariaDB
$Php = Find-Program $Php 'php' @('C:\xampp\php\php.exe', 'D:\xampp\php\php.exe')
$MySqld = Find-Program $MySqld 'mysqld' @('C:\xampp\mysql\bin\mysqld.exe', 'D:\xampp\mysql\bin\mysqld.exe', 'C:\Program Files\MySQL\MySQL Server 8.*\bin\mysqld.exe')
if (-not $Php) { throw '没有找到 PHP。请安装 XAMPP 或 PHP 7.4+，或用 -Php 指定 php.exe 的位置。' }
if (-not $MySqld) { throw '没有找到 MySQL / MariaDB。请安装 XAMPP 或 MySQL 8，或用 -MySqld 指定 mysqld.exe 的位置。' }
$Bin = Split-Path -Parent $MySqld
$Client = @('mysql.exe', 'mariadb.exe') | ForEach-Object { Join-Path $Bin $_ } | Where-Object { Test-Path $_ } | Select-Object -First 1
$IsMariaDb = (& $MySqld --version) -match 'MariaDB'
Write-Host "PHP:    $Php"
Write-Host "数据库: $MySqld"

# 2. PHP 配置：在示例配置后面写上本机 PHP 的扩展目录
$Ini = Join-Path $Data 'php.ini'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'php.ini.example') -Destination $Ini -Force
Add-Content -LiteralPath $Ini ('extension_dir="' + (Join-Path (Split-Path -Parent $Php) 'ext') + '"')

# 3. 首次运行：初始化一个只给本作业用的数据库目录
$Db = Join-Path $DbHome 'mysql'
$FirstRun = -not (Test-Path -LiteralPath $Db)
if ($FirstRun) {
  Write-Host '首次运行：初始化数据库……'
  if ($IsMariaDb) {
    $Install = Join-Path $Bin 'mysql_install_db.exe'
    if (-not (Test-Path $Install)) { $Install = Join-Path $Bin 'mariadb-install-db.exe' }
    & $Install "--datadir=$Db" | Out-Null
  } else {
    & $MySqld --no-defaults --initialize-insecure "--datadir=$Db" 2>&1 | Out-Null
  }
  if ($LASTEXITCODE -ne 0) { Remove-Item -Recurse -Force $Db -ErrorAction SilentlyContinue; throw "数据库初始化失败（数据目录 $Db）。" }
}

# 4. 启动数据库（只监听本机）
if (Test-Port $DbPort) { throw "端口 $DbPort 已被占用。如果是上次没关掉的本站点，先运行 停止.bat。" }
$DbArgs = @('--no-defaults', "--datadir=`"$Db`"", "--port=$DbPort", '--bind-address=127.0.0.1', '--console')
if (-not $IsMariaDb) { $DbArgs += '--mysqlx=OFF' }
Start-Process -FilePath $MySqld -ArgumentList $DbArgs -WindowStyle Hidden -RedirectStandardOutput (Join-Path $Logs 'mysql.out.log') -RedirectStandardError (Join-Path $Logs 'mysql.err.log')
for ($i = 0; $i -lt 60 -and -not (Test-Port $DbPort); $i++) { Start-Sleep -Seconds 1 }
if (-not (Test-Port $DbPort)) { throw "数据库没有启动，请查看 logs\mysql.err.log。" }

# 5. 首次运行：建库、建账号、导入站点数据
if ($FirstRun) {
  Write-Host '首次运行：导入站点数据……'
  # 导入文件也先复制到纯英文路径
  Copy-Item -LiteralPath (Join-Path $Root 'database\hw3_wordpress.sql') -Destination (Join-Path $DbHome 'hw3_wordpress.sql') -Force
  $Sql = (Join-Path $DbHome 'hw3_wordpress.sql').Replace('\', '/')
  $Setup = "CREATE DATABASE hw3_wordpress CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; " +
           "CREATE USER 'hw3_wp'@'localhost' IDENTIFIED BY 'hw3_wp_local'; CREATE USER 'hw3_wp'@'127.0.0.1' IDENTIFIED BY 'hw3_wp_local'; " +
           "GRANT ALL PRIVILEGES ON hw3_wordpress.* TO 'hw3_wp'@'localhost'; GRANT ALL PRIVILEGES ON hw3_wordpress.* TO 'hw3_wp'@'127.0.0.1'; FLUSH PRIVILEGES;"
  & $Client --host=127.0.0.1 "--port=$DbPort" --user=root "--execute=$Setup"
  & $Client --host=127.0.0.1 "--port=$DbPort" --user=root --default-character-set=utf8mb4 hw3_wordpress "--execute=source $Sql"
  if ($LASTEXITCODE -ne 0) { throw "导入站点数据失败。运行 停止.bat，删除 $DbHome 后可以重新运行。" }
}

# 6. 启动网站
if (Test-Port $HttpPort) { throw "端口 $HttpPort 已被占用。如果是上次没关掉的本站点，先运行 停止.bat。" }
Start-Process -FilePath $Php -ArgumentList @('-c', "`"$Ini`"", '-S', "127.0.0.1:$HttpPort", '-t', "`"$(Join-Path $Root 'wordpress')`"") -WindowStyle Hidden -RedirectStandardOutput (Join-Path $Logs 'php.out.log') -RedirectStandardError (Join-Path $Logs 'php.err.log')
for ($i = 0; $i -lt 20 -and -not (Test-Port $HttpPort); $i++) { Start-Sleep -Milliseconds 500 }

$Url = "http://127.0.0.1:$HttpPort/"
Write-Host ''
Write-Host "站点已启动：$Url" -ForegroundColor Green
Write-Host "后台：${Url}wp-admin/   账号见 README.md"
Write-Host '关闭站点：双击 停止.bat'
if (-not $NoBrowser) { Start-Process $Url }
