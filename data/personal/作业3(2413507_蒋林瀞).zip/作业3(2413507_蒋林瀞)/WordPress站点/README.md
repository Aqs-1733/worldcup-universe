# WordPress 站点安装说明（作业3，2413507 蒋林瀞）

环境：WordPress 7.1.3、PHP 8.4、MySQL 8.0、主题 Twenty Twenty-Five 1.5、插件 TablePress 3.4.1（下载地址和校验值见 `scripts/versions-and-sources.json`）。

- `site/`：站点内容（页面、文章、全局样式、页眉页脚模板、首页图片、TablePress 示例表），不含账号、密码和数据库文件。
- `scripts/`：准备数据库（`Prepare-Database.php`）、导入站点内容（`Restore-Content.php`）、启动已安装的站点（`Start-Homework3.ps1`）、PHP 配置示例（`php.ini.example`）。

## 安装步骤

以下命令都在本目录（`WordPress站点`）中的 PowerShell 执行。先设置三个变量：PHP 和 MySQL 已加入 PATH 时保持默认即可，否则改成自己电脑上的程序位置。WordPress 会安装到本目录下新建的 `server` 文件夹，数据库端口 3338，网站端口 8085。

```powershell
$Php    = 'php'         # PHP 8.x
$MySqld = 'mysqld'      # MySQL 8.0 的 mysqld
$Server = '.\server'    # 新建的运行目录
```

1. 检查版本，并确认端口没有被占用（最后一条没有输出就说明端口空闲）：

```powershell
& $Php -v
& $MySqld --version
Get-NetTCPConnection -LocalPort 3338,8085 -State Listen -ErrorAction SilentlyContinue
```

2. 下载 WordPress 并准备目录：

```powershell
New-Item -ItemType Directory -Path $Server | Out-Null
$Server = (Resolve-Path $Server).Path
Invoke-WebRequest 'https://wordpress.org/wordpress-7.1.3.zip' -OutFile "$Server\wordpress.zip"
Expand-Archive -LiteralPath "$Server\wordpress.zip" -DestinationPath $Server
New-Item -ItemType Directory -Path "$Server\mysql-data" | Out-Null
Copy-Item -LiteralPath '.\scripts\php.ini.example' -Destination "$Server\php.ini"
Add-Content "$Server\php.ini" ("extension_dir=`"" + (Join-Path (Split-Path (Get-Command $Php).Source) 'ext') + "`"")
```

最后一行把 PHP 安装目录下的 `ext` 文件夹写进配置，这样 mysqli 等扩展才能加载。所有 php 命令都用 `-c` 指向这份配置，不修改全局 php.ini。

3. 初始化并启动一个新的 MySQL 实例（`--initialize-insecure` 只用于新建的本机实例，下一步会为 root 和站点账号生成随机密码）：

```powershell
& $MySqld --no-defaults --initialize-insecure --datadir="$Server\mysql-data" --console
Start-Process -FilePath $MySqld -ArgumentList '--no-defaults',"--datadir=`"$Server\mysql-data`"",'--port=3338','--bind-address=127.0.0.1','--mysqlx=OFF','--console' -WindowStyle Hidden -RedirectStandardOutput "$Server\mysql.out.log" -RedirectStandardError "$Server\mysql.err.log"
```

等 `server\mysql.err.log` 中出现 `ready for connections` 后，创建数据库并启动网站：

```powershell
& $Php -c "$Server\php.ini" '.\scripts\Prepare-Database.php' $Server 3338
Start-Process -FilePath $Php -ArgumentList '-c',"`"$Server\php.ini`"",'-S','127.0.0.1:8085','-t',"`"$Server\wordpress`"" -WindowStyle Hidden -RedirectStandardOutput "$Server\php.out.log" -RedirectStandardError "$Server\php.err.log"
```

`Prepare-Database.php` 会创建 `hw3_wordpress` 数据库、只能访问这个库的 `hw3_wp` 账号，并写好 `wp-config.php`（表前缀 `hw3_`）；配置已存在时不会覆盖。

4. 浏览器打开 http://127.0.0.1:8085/wp-admin/install.php ，填写站点标题、管理员账号、自己设置的密码和邮箱，点击 Install WordPress，然后登录后台。

5. 在“外观 → 主题”启用 Twenty Twenty-Five。在“插件 → 安装插件 → 上传插件”上传从 `https://downloads.wordpress.org/plugin/tablepress.3.4.1.zip` 下载的压缩包，安装并启用。

6. 页面制作过程见实验报告：新建首页、关于、手记、清单页面，发布两篇手记，首页和手记页加入“查询循环”区块，在“设置 → 阅读”中选择静态首页；在 TablePress 中导入 `site/cities-example.csv`，把 `[table id=1 /]` 放进清单页。

之后再次启动站点：

```powershell
.\scripts\Start-Homework3.ps1 -Server $Server -Php $Php -MySqld $MySqld
```

## 可选：一次导入报告中的页面与布局

完成上面的安装、主题和插件启用后，可以用 WP-CLI 把 `site` 中的页面、文章、样式、模板、图片和表格一次导入（只接受刚安装、还没有内容的站点）：

```powershell
Invoke-WebRequest 'https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar' -OutFile "$Server\wp-cli.phar"
& $Php -c "$Server\php.ini" "$Server\wp-cli.phar" eval-file '.\scripts\Restore-Content.php' '.\site' --path="$Server\wordpress"
```

导入通过 WordPress 和 TablePress 自己的接口完成，会重新分配页面和图片编号，并把时区设为上海。
