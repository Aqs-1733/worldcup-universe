<?php
// Run only through WP-CLI, against a freshly initialized WordPress site.
if (!defined('WP_CLI') || !WP_CLI) { exit(1); }
wp_set_current_user(1);
$content=$args[0] ?? dirname(__DIR__).'/site';
$data=json_decode(file_get_contents($content.'/site-content.json'),true,512,JSON_THROW_ON_ERROR);
if (get_option('hw3_content_restored')) { WP_CLI::error('Content already restored.'); }
foreach(get_posts(['post_type'=>['page','post'],'post_status'=>'publish','numberposts'=>-1]) as $p) {
 if (!in_array($p->post_name,['hello-world','sample-page'],true)) { WP_CLI::error('Use a fresh installation; existing content found.'); }
}
if (!class_exists('TablePress')) { WP_CLI::error('Activate TablePress 3.4.1 first.'); }
if (TablePress::$model_table->load_all()) { WP_CLI::error('Use a fresh installation without existing TablePress tables.'); }
switch_theme('twentytwentyfive');
update_option('timezone_string','Asia/Shanghai');
require_once ABSPATH.'wp-admin/includes/file.php';
require_once ABSPATH.'wp-admin/includes/media.php';
require_once ABSPATH.'wp-admin/includes/image.php';
$tmp=wp_tempnam('stadium-hero-v2.png');copy($content.'/stadium-hero-v2.png',$tmp);
$media=media_handle_sideload(['name'=>'stadium-hero-v2.png','tmp_name'=>$tmp],0,'球场边线 · 设计插图');
if(is_wp_error($media)){WP_CLI::error($media->get_error_message());}
update_post_meta($media,'_wp_attachment_image_alt','夕阳下的球场角旗与边线，AI设计插图');
$rewrite=static function($content) use($data,$media){return str_replace([$data['source_media_url'],$data['source_url'],'"id":'.$data['source_media_id'],'wp-image-'.$data['source_media_id']],[wp_get_attachment_url($media),home_url(),'"id":'.$media,'wp-image-'.$media],$content);};
$table=array_replace_recursive(TablePress::$model_table->get_table_template(),$data['table']);
$table['id']=false;$table['author']=1;$table['options']['last_editor']=1;
$tableid=TablePress::$model_table->add($table);
if(is_wp_error($tableid)){WP_CLI::error($tableid->get_error_message());}
foreach(get_posts(['post_type'=>['page','post'],'post_status'=>'publish','numberposts'=>-1]) as $p){wp_trash_post($p->ID);}
$ids=[];
foreach($data['posts'] as $p){
 $p['post_status']='publish';$p['post_author']=1;
 $p['post_content']=str_replace('[table id=1 /]','[table id='.$tableid.' /]',$rewrite($p['post_content']));
 $id=wp_insert_post(wp_slash($p),true);if(is_wp_error($id)){WP_CLI::error($id->get_error_message());}$ids[$p['post_name']]=$id;
}
foreach($data['templates'] as $p){
 $p['post_content']=$rewrite($p['post_content']);$p['post_status']='publish';
 $id=wp_insert_post(wp_slash($p),true);if(is_wp_error($id)){WP_CLI::error($id->get_error_message());}
 wp_set_object_terms($id,'twentytwentyfive','wp_theme');
 if($p['post_type']==='wp_template_part'){wp_set_object_terms($id,$p['post_name'],'wp_template_part_area');}
}
$sid=WP_Theme_JSON_Resolver::get_user_global_styles_post_id();
wp_update_post(['ID'=>$sid,'post_content'=>wp_slash(wp_json_encode($data['global_styles']))]);
wp_update_custom_css_post($data['css']);
foreach(['blogname'=>'边线之外','blogdescription'=>'从足球出发，看见更大的世界。','timezone_string'=>'Asia/Shanghai','show_on_front'=>'page','page_on_front'=>$ids['home'],'permalink_structure'=>'','blog_public'=>'0','default_comment_status'=>'closed'] as $k=>$v){update_option($k,$v);}
wp_update_user(['ID'=>1,'display_name'=>'边线之外编辑室']);
update_option('hw3_content_restored',true);
WP_CLI::success('Restored four pages, two posts, native templates, styles, image and one TablePress table.');
