# WordPress 站点复现说明（作业3，2413507 蒋林瀞）

环境：WordPress 7.1.3、PHP 8.4、MySQL 8.0、主题 Twenty Twenty-Five 1.5、插件 TablePress 3.4.1（版本与官方下载地址见 reproduce/versions-and-sources.json）。

- `site-backup/`：站点内容备份（页面、文章、全局样式、页眉页脚模板、首页图片、TablePress 示例表），不含账号、密码和数据库转储。
- `reproduce/`：准备数据库（Prepare-Database.php）、恢复内容（Restore-Content.php）、启动已有站点（Start-Homework3.ps1）、php.ini 示例。

下面的命令中的程序路径（PHP、MySQL 安装位置）是作者电脑上的路径，在其他电脑上请换成自己的安装位置。

## 从空目录重新安装

以下在 PowerShell 执行。示例用新目录 `D:\internet\.runtime\hw3-rebuild`、数据库端口 3338 和 HTTP 端口 8085；不要将新建目录替换为既有项目或数据库目录。程序路径对应本机已核实的已有安装。

1. 检查 PHP、MySQL 版本与端口：

```powershell
& 'D:\internet\.runtime\php-8.4.25\php.exe' -v
& 'D:\MySQL\MySQL Server 8.0\bin\mysqld.exe' --version
Get-NetTCPConnection -LocalPort 3338,8085 -State Listen -ErrorAction SilentlyContinue
```

2. 确认目录不存在、端口空闲后，下载官方发行包并创建目录。原始安装使用 WordPress 的 latest.zip，落地版本经文件和后台核对为 7.1.3；复现固定该版本。

```powershell
$hw3Rebuild='D:\internet\.runtime\hw3-rebuild'
if(Test-Path -LiteralPath $hw3Rebuild){throw 'Use a new, empty runtime directory'}
New-Item -ItemType Directory -Path $hw3Rebuild | Out-Null
Invoke-WebRequest 'https://wordpress.org/wordpress-7.1.3.zip' -OutFile "$hw3Rebuild\wordpress.zip"
Expand-Archive -LiteralPath "$hw3Rebuild\wordpress.zip" -DestinationPath $hw3Rebuild
New-Item -ItemType Directory -Path "$hw3Rebuild\mysql-data" | Out-Null
Copy-Item -LiteralPath '.\reproduce\php.ini.example' -Destination "$hw3Rebuild\php.ini"
```

若 PHP 程序放在其他位置，先修改复制后的 php.ini 中 `extension_dir`。必须启用 mysqli；其余扩展见示例文件。所有 php 命令均用 `-c` 指向本作业配置，不修改全局 php.ini。

3. 初始化并启动新 MySQL 实例。`--initialize-insecure` 仅用于新建本机实例，下一步立即为 root 和站点账户生成随机密码。

```powershell
& 'D:\MySQL\MySQL Server 8.0\bin\mysqld.exe' --no-defaults --initialize-insecure '--basedir=D:/MySQL/MySQL Server 8.0' --datadir="$hw3Rebuild\mysql-data" --console
Start-Process -FilePath 'D:\MySQL\MySQL Server 8.0\bin\mysqld.exe' -ArgumentList '--no-defaults','--basedir="D:/MySQL/MySQL Server 8.0"',"--datadir=`"$hw3Rebuild\mysql-data`"",'--port=3338','--bind-address=127.0.0.1','--mysqlx=OFF','--console' -WindowStyle Hidden -RedirectStandardOutput "$hw3Rebuild\mysql.out.log" -RedirectStandardError "$hw3Rebuild\mysql.err.log"
```

确认 mysql.err.log 出现 `ready for connections` 和 `port: 3338`，再执行：

```powershell
& 'D:\internet\.runtime\php-8.4.25\php.exe' -c "$hw3Rebuild\php.ini" '.\reproduce\Prepare-Database.php' $hw3Rebuild 3338
Start-Process -FilePath 'D:\internet\.runtime\php-8.4.25\php.exe' -ArgumentList '-c',"`"$hw3Rebuild\php.ini`"",'-S','127.0.0.1:8085','-t',"`"$hw3Rebuild\wordpress`"" -WindowStyle Hidden -RedirectStandardOutput "$hw3Rebuild\php.out.log" -RedirectStandardError "$hw3Rebuild\php.err.log"
```

Prepare-Database.php 会核验真实实例端口和数据目录，创建 `hw3_wordpress` 数据库、仅获该库权限的 `hw3_wp` 账户及 `hw3_` 表前缀配置。若配置已存在则拒绝覆盖；不会打印密码。

4. 浏览器打开 http://127.0.0.1:8085/wp-admin/install.php ，填写标题、管理员账号、自己设置的强密码和示例邮箱（如 student@example.test），勾选不希望被搜索引擎收录，点击 Install WordPress。看到 Success 后登录后台。中文语言包在本轮下载失败，实验后台使用英文，中文正文正常。

5. 在 Appearance → Themes 保留并核验 Twenty Twenty-Five。Plugins → Add Plugin → Upload Plugin，上传从 `https://downloads.wordpress.org/plugin/tablepress.3.4.1.zip` 下载的 ZIP，点击 Install Now、Activate Plugin；首次提示选择 Skip，不使用付费功能。

6. 如从头手工编辑：Pages → Add Page，用标题、段落、分栏、图片、按钮建立首页；新建关于、手记和清单页面。Posts → Add Post 发布两篇示例手记。首页和手记页放入 Query Loop。Settings → Reading 选择静态首页。TablePress → Import 导入 `site-backup/cities-example.csv`，保留搜索、排序及水平滚动，将 `[table id=1 /]` 放入清单页的 Shortcode 区块。站点模板与全局样式配置见报告。

## 可选：恢复本次实际页面与布局

备份为白名单内容导出，包含原生区块内容、全局样式、原生页眉页脚及页面模板、图片和 TablePress 示例表；不包含用户表、密码、数据库转储、wp-config.php、认证 Cookie 或密钥。它不是整站镜像。

先完成上面的空站安装、主题选择与插件激活，再下载官方 WP-CLI：

```powershell
Invoke-WebRequest 'https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar' -OutFile "$hw3Rebuild\wp-cli.phar"
& 'D:\internet\.runtime\php-8.4.25\php.exe' -c "$hw3Rebuild\php.ini" "$hw3Rebuild\wp-cli.phar" eval-file '.\reproduce\Restore-Content.php' '.\site-backup' --path="$hw3Rebuild\wordpress"
```

在本包根目录执行以上相对路径命令。恢复脚本仅接受新安装且没有既有 TablePress 表的站点，并拒绝重复恢复。它通过 WordPress/TablePress API 导入内容，重新分配媒体和页面 ID、替换站点图片 URL，先设置上海时区并保留 UTC 发布时间。全站仍由原主题和原生区块管理，没有新增自定义 PHP/React/Vue 网站。


