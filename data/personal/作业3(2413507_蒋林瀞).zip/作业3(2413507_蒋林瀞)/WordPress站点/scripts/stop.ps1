﻿# 文件作用：关闭由 一键启动.bat 启动的网站（PHP）和数据库（MySQL / MariaDB），数据保留在 data 文件夹。
# 作者：蒋林瀞_2413507
param([int]$HttpPort = 8085, [int]$DbPort = 3338)
foreach ($port in $HttpPort, $DbPort) {
  Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | ForEach-Object {
    $p = Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue
    if ($p -and $p.ProcessName -match '^(php|mysqld|mariadbd)$') { Stop-Process -Id $p.Id -Force; Write-Host "已关闭 $($p.ProcessName)（端口 $port）" }
  }
}
Write-Host '完成。'
