param(
 [string]$RuntimeDir='D:\internet\.runtime\homework3',
 [string]$PhpExe='D:\internet\.runtime\php-8.4.25\php.exe',
 [string]$MySqlBase='D:\MySQL\MySQL Server 8.0',
 [int]$HttpPort=8083,
 [int]$DbPort=3337
)
$ErrorActionPreference='Stop'
if(!(Test-Path -LiteralPath "$RuntimeDir\wordpress\wp-config.php")){throw 'Existing WordPress configuration not found. Follow README installation steps first.'}
if(!(Get-NetTCPConnection -LocalPort $DbPort -State Listen -ErrorAction SilentlyContinue)){
 Start-Process -FilePath "$MySqlBase\bin\mysqld.exe" -ArgumentList '--no-defaults',"--basedir=`"$MySqlBase`"","--datadir=`"$RuntimeDir\mysql-data`"","--port=$DbPort",'--bind-address=127.0.0.1','--mysqlx=OFF','--console' -WindowStyle Hidden -RedirectStandardOutput "$RuntimeDir\mysql.out.log" -RedirectStandardError "$RuntimeDir\mysql.err.log"
} else {Write-Output "Port $DbPort already has a listener; no service changed."}
if(!(Get-NetTCPConnection -LocalPort $HttpPort -State Listen -ErrorAction SilentlyContinue)){
 Start-Process -FilePath $PhpExe -ArgumentList '-c',"`"$RuntimeDir\php.ini`"",'-S',"127.0.0.1:$HttpPort",'-t',"`"$RuntimeDir\wordpress`"" -WindowStyle Hidden -RedirectStandardOutput "$RuntimeDir\php.out.log" -RedirectStandardError "$RuntimeDir\php.err.log"
} else {Write-Output "Port $HttpPort already has a listener; no service changed."}
Write-Output "Open http://127.0.0.1:$HttpPort/ and http://127.0.0.1:$HttpPort/wp-admin/"
