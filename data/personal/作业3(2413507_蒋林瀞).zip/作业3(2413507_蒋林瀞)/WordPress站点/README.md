# WordPress 站点（作业3，2413507 蒋林瀞）

这是实验报告中搭建完成的 WordPress 站点“边线之外”，包含全部页面、文章、主题设置、TablePress 插件和表格、图片，以及数据库导出。双击即可在本机运行，不需要另外下载或安装 WordPress。

环境：WordPress 7.1.3、主题 Twenty Twenty-Five 1.5、插件 TablePress 3.4.1（下载地址和校验值见 `scripts/versions-and-sources.json`）。

| 目录 / 文件 | 内容 |
|---|---|
| `wordpress/` | 完整的 WordPress 站点文件（含主题、插件、上传的图片） |
| `database/hw3_wordpress.sql` | 站点数据库导出 |
| `一键启动.bat` | 启动站点；首次运行会自动建库并导入数据 |
| `停止.bat` | 关闭站点 |
| `scripts/` | 启动 / 停止脚本和 PHP 配置 |

## 运行

需要电脑上有 PHP 7.4 及以上和 MySQL 8 / MariaDB 10.4 及以上。安装 XAMPP 即可满足（脚本会自动在 PATH 和 `C:\xampp`、`D:\xampp` 中查找）。

1. 双击 `一键启动.bat`。首次运行会初始化一个只给本站用的数据库并导入数据，大约需要半分钟。
2. 浏览器会自动打开 http://127.0.0.1:8085/ 。首次打开页面稍慢，之后正常。
3. 后台：http://127.0.0.1:8085/wp-admin/ ，用户名 `hw3_editor`，密码 `GeminaiLong-0cb6v43w`（仅用于本机演示）。
4. 使用完后双击 `停止.bat` 关闭。

页面：首页、关于（`/?pagename=about`）、观察手记（`/?pagename=journal`）、城市观察清单（`/?pagename=directory`，含 TablePress 表格）。

## 说明

- PHP 或 MySQL 不在默认位置时，可以在命令行指定，例如：

  ```powershell
  .\一键启动.bat -Php "D:\php\php.exe" -MySqld "D:\MySQL\bin\mysqld.exe"
  ```

- 网站使用端口 8085，数据库使用端口 3338，只监听本机。端口被占用时，脚本会给出提示。
- MySQL 不能在含中文的路径下运行，所以数据库文件保存在 `%LOCALAPPDATA%\GeminaiLong-hw3`（用户目录含中文时为 `C:\GeminaiLong-hw3`）。删除这个文件夹后再次启动，会重新导入一份全新的站点数据。
- 运行日志保存在本目录的 `logs` 文件夹。
