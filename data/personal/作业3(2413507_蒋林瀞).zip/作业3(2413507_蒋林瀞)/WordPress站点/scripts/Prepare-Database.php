<?php
// CLI helper for a NEW, isolated MySQL instance. Contains no fixed passwords.
if (PHP_SAPI!=='cli') { exit(1); }
$runtime=realpath($argv[1] ?? '');$port=(int)($argv[2] ?? 0);
if(!$runtime || $port<1024 || !is_file($runtime.'/wordpress/wp-config-sample.php')){throw new RuntimeException('Usage: php Prepare-Database.php NEW_RUNTIME DB_PORT');}
if(is_file($runtime.'/credentials.private.json') || is_file($runtime.'/wordpress/wp-config.php')){throw new RuntimeException('Refusing to overwrite existing configuration');}
$db=new mysqli('127.0.0.1','root','',null,$port);
$v=$db->query('SELECT @@datadir AS dir,@@port AS port')->fetch_assoc();
$normalize=static fn($s)=>strtolower(str_replace('\\','/',rtrim($s,'/\\')));
if((int)$v['port']!==$port || $normalize($v['dir'])!==$normalize($runtime.'/mysql-data')){throw new RuntimeException('Database instance boundary check failed');}
$secret=['db'=>bin2hex(random_bytes(24)),'root'=>bin2hex(random_bytes(24))];
$db->query('CREATE DATABASE hw3_wordpress CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
$db->query("CREATE USER 'hw3_wp'@'localhost' IDENTIFIED BY '{$secret['db']}'");
$db->query("GRANT ALL ON hw3_wordpress.* TO 'hw3_wp'@'localhost'");
$db->query("ALTER USER 'root'@'localhost' IDENTIFIED BY '{$secret['root']}'");
file_put_contents($runtime.'/credentials.private.json',json_encode($secret));
$cfg=file_get_contents($runtime.'/wordpress/wp-config-sample.php');
$cfg=str_replace(['database_name_here','username_here','password_here','localhost'],['hw3_wordpress','hw3_wp',$secret['db'],'127.0.0.1:'.$port],$cfg);
$cfg=str_replace("$"."table_prefix = 'wp_'", "$"."table_prefix = 'hw3_'",$cfg);
$cfg=preg_replace_callback('/put your unique phrase here/',fn()=>bin2hex(random_bytes(32)),$cfg);
$cfg=str_replace("/* That's all","define('FS_METHOD','direct');\ndefine('WP_ENVIRONMENT_TYPE','local');\ndefine('DISABLE_WP_CRON',true);\n/* That's all",$cfg);
file_put_contents($runtime.'/wordpress/wp-config.php',$cfg);
echo "Isolated database and configuration prepared. Keep credentials.private.json local.\n";
