<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'hw3_wordpress' );

/** Database username */
define( 'DB_USER', 'hw3_wp' );

/** Database password */
define( 'DB_PASSWORD', 'hw3_wp_local' ); // 只在本机 127.0.0.1 上使用的数据库账号，由 scripts/start.ps1 首次运行时创建

/** Database hostname */
define( 'DB_HOST', '127.0.0.1:3338' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'c879e0e9dfb9fa3370f9130a57c3a15126e8c07b686c20fabb623bed1d338ffd' );
define( 'SECURE_AUTH_KEY',  '453d78ff4036ff42308a0a777751896711dcb521fb5f1bca363e10ae80817d13' );
define( 'LOGGED_IN_KEY',    '3f81c0a8a6917877a364b99b2b82037c5873e8fbb5c764bc275d44f8e9f66db1' );
define( 'NONCE_KEY',        'f12e0682622f0659948cd5f52e55ba84db6fe4c77f05eec637a0836d54f46857' );
define( 'AUTH_SALT',        '55cbd8039f604fb7f56db308e4ec84c00ac2d04a1de2aaade42c20c1a8592bcd' );
define( 'SECURE_AUTH_SALT', 'a497703045943d3e22d884f30e3c150fc47ce4cfdc4ba564051f3172ded1995d' );
define( 'LOGGED_IN_SALT',   '0c6d05c367caecee2665e4ecde1ff0148024fc22d1ca01291a949e26f485036c' );
define( 'NONCE_SALT',       'b91752174c995243b38156e6d9b35e10f0a0038a94981d623dc165f06a2fbb57' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'hw3_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



define('FS_METHOD','direct');
// 站点地址跟随浏览器访问的地址，换电脑或换端口也能正常打开
if (!empty($_SERVER['HTTP_HOST'])) { define('WP_HOME','http://'.$_SERVER['HTTP_HOST']); define('WP_SITEURL','http://'.$_SERVER['HTTP_HOST']); }
define('WP_ENVIRONMENT_TYPE','local');
define('DISABLE_WP_CRON',true);
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
