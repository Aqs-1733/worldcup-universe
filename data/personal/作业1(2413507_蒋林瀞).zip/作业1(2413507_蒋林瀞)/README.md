# 个人作业1 Web 前端初探

2413507 蒋林瀞

## 提交内容

| 文件 | 内容 |
|---|---|
| `作业1(2413507_蒋林瀞).pdf` | 实验报告：GET/POST（及 PUT/PATCH）请求与响应、jQuery 页面事件、浏览器插件的功能与代码 |
| `jquery-实验代码.html` | jQuery 实验页面，浏览器直接打开（需联网加载 jQuery 3.7.1） |
| `HTTP补充实验/` | PUT、PATCH 请求实验页面 |
| `DomainSentinel浏览器插件.zip` | 浏览器插件 URL Sentinel：已构建的扩展、完整源码和一键启动脚本，使用方法见压缩包内的 `README.md` |

## 对应课程要求

1. **GET、POST 请求**：报告第 2 节。插件后端也提供可在 Network 面板查看的接口：
   - `GET http://127.0.0.1:8001/api/domain-info?domain=example.com`：域名查询，返回 `{"domain":"example.com","normalized_domain":"example.com","method":"GET"}`
   - `POST http://127.0.0.1:8001/detect`：网址检测，请求体为 `{"url":"https://login.example.test/account/update?next=https://safe.test"}`，返回风险等级、证据和模型信息
2. **jQuery 事件**：报告第 3 节，页面为 `jquery-实验代码.html`。插件源码中的演示页 `plugin-source/frontend/` 也有一组 jQuery 交互：

   ```javascript
   $("#protection-btn").on("click", function () {
     $("#protection-status").text("Protection Mode: Enabled");
     $("#protection-panel").addClass("is-enabled");
     $("#protection-details").slideToggle(250);
     $(this).prop("disabled", true).text("Protection Enabled");
   });
   ```

3. **浏览器插件**：报告第 4 节。URL Sentinel 在访问网址前分析风险：提取网址特征、匹配可信域名、运行规则，再由大模型初筛和复核，高风险网址会被拦截并说明原因。

## 运行插件

1. 解压 `DomainSentinel浏览器插件.zip`，双击其中的 `一键启动.bat`（需要 Python 3.10 及以上和网络）。它会启动检测服务 `http://127.0.0.1:8001` 和产品页面 `http://127.0.0.1:4173/tabs/home.html`。
2. 在 Chrome 打开 `chrome://extensions`，开启“开发者模式”，点击“加载已解压的扩展程序”，选择压缩包中的 `plugin-installable` 目录。
3. 把 URL Sentinel 固定到工具栏，点击图标即可检测当前网页；访问高风险网址时会自动跳到拦截页。

查看 GET / POST 演示页：在 `plugin-source` 目录运行下面的命令，然后打开 `http://127.0.0.1:4174/`，按 F12 在 Network 面板查看请求和响应。

```powershell
python -m http.server 4174 --bind 127.0.0.1 --directory frontend
```
