@echo off
rem 一键启动作业3的 WordPress 站点（首次运行会初始化数据库并导入数据）
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1" %*
pause
