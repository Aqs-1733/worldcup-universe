# Start an existing WordPress site created by the steps in ..\README.md (MySQL + PHP built-in server).
# Run from the WordPress站点 folder; pass -Php / -MySqld if they are not on PATH.
param(
 [string]$Server = '.\server',
 [string]$Php = 'php',
 [string]$MySqld = 'mysqld',
 [int]$HttpPort = 8085,
 [int]$DbPort = 3338
)
$ErrorActionPreference = 'Stop'
$Server = (Resolve-Path -LiteralPath $Server).Path
if (!(Test-Path -LiteralPath "$Server\wordpress\wp-config.php")) { throw 'WordPress is not installed in this folder yet. Follow README.md first.' }
if (!(Get-NetTCPConnection -LocalPort $DbPort -State Listen -ErrorAction SilentlyContinue)) {
 Start-Process -FilePath $MySqld -ArgumentList '--no-defaults', "--datadir=`"$Server\mysql-data`"", "--port=$DbPort", '--bind-address=127.0.0.1', '--mysqlx=OFF', '--console' -WindowStyle Hidden -RedirectStandardOutput "$Server\mysql.out.log" -RedirectStandardError "$Server\mysql.err.log"
} else { Write-Output "Port $DbPort already in use; database not started again." }
if (!(Get-NetTCPConnection -LocalPort $HttpPort -State Listen -ErrorAction SilentlyContinue)) {
 Start-Process -FilePath $Php -ArgumentList '-c', "`"$Server\php.ini`"", '-S', "127.0.0.1:$HttpPort", '-t', "`"$Server\wordpress`"" -WindowStyle Hidden -RedirectStandardOutput "$Server\php.out.log" -RedirectStandardError "$Server\php.err.log"
} else { Write-Output "Port $HttpPort already in use; web server not started again." }
Write-Output "Open http://127.0.0.1:$HttpPort/ and http://127.0.0.1:$HttpPort/wp-admin/"
